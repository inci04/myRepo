import pytest
from calculator import Calculator


def test_add():
    xCalculator=Calculator()
    assert xCalculator.add(5,6)==11

def test_subtract():
    xCalculator=Calculator()
    assert xCalculator.subtract(3,6)==-3

def test_multiply():
    xCalculator=Calculator()
    assert xCalculator.multiply(5,6)==30

def test_divide():
    xCalculator=Calculator()
    assert xCalculator.divide(15,3)==5
    
def test_divide_by_zero():
    xCalculator = Calculator()
    with pytest.raises(ValueError):
        xCalculator.divide(10, 0)

  